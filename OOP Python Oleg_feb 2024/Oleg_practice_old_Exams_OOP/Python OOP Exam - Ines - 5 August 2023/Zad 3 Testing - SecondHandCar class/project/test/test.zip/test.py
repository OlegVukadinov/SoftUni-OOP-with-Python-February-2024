import unittest

from project.second_hand_car import SecondHandCar


class TestSecondHandCar(unittest.TestCase):
    def setUp(self):
        self.car = SecondHandCar("Toyota", "SUV", 20000, 15000.0)

    def test_set_promotional_price(self):
        # Test setting promotional price
        self.assertEqual(self.car.set_promotional_price(12000.0), 'The promotional price has been successfully set.')
        self.assertEqual(self.car.price, 12000.0)

    def test_set_promotional_price_invalid_price(self):
        # Test setting promotional price with invalid price
        with self.assertRaises(ValueError):
            self.car.set_promotional_price(16000.0)

    def test_need_repair(self):
        # Test need repair function
        self.assertEqual(self.car.need_repair(2000.0, "Replace brakes"), 'Price has been increased due to repair charges.')
        self.assertEqual(self.car.price, 17000.0)
        self.assertEqual(len(self.car.repairs), 1)

    def test_need_repair_invalid_repair(self):
        # Test need repair with repair price exceeding half of car price
        self.assertEqual(self.car.need_repair(10000.0, "Replace engine"), 'Repair is impossible!')
        self.assertEqual(self.car.price, 15000.0)
        self.assertEqual(len(self.car.repairs), 0)

    def test_gt_comparison_same_type(self):
        # Test comparison with greater than operator for cars of the same type
        car2 = SecondHandCar("Honda", "SUV", 25000, 14000.0)
        self.assertTrue(self.car > car2)

    def test_gt_comparison_different_type(self):
        # Test comparison with greater than operator for cars of different types
        car3 = SecondHandCar("Toyota", "Sedan", 18000, 16000.0)
        self.assertEqual(self.car > car3, 'Cars cannot be compared. Type mismatch!')

    def test_price_setter(self):
        # Test price setter
        with self.assertRaises(ValueError):
            self.car.price = 0.5

    def test_mileage_setter(self):
        # Test mileage setter
        with self.assertRaises(ValueError):
            self.car.mileage = 50

if __name__ == '__main__':
    unittest.main()
