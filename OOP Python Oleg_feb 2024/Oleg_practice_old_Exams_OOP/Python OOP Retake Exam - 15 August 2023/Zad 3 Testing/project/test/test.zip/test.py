import unittest

from project.trip import Trip


# Assuming your class is in a module named 'trip'

class TestTrip(unittest.TestCase):
    def setUp(self):
        self.trip = Trip(10000, 4, False)

    def test_book_a_trip_success(self):
        # Test booking a trip successfully
        self.assertEqual(self.trip.book_a_trip('Australia'),
                         'Successfully booked destination Australia! Your budget left is 1300.00')

    def test_book_a_trip_invalid_destination(self):
        # Test booking with an invalid destination
        self.assertEqual(self.trip.book_a_trip('Italy'),
                         'This destination is not in our offers, please choose a new one!')

    def test_book_a_trip_insufficient_budget(self):
        # Test booking with insufficient budget
        self.trip.budget = 100
        self.assertEqual(self.trip.book_a_trip('New Zealand'),
                         'Your budget is not enough!')

    def test_booking_status_no_bookings(self):
        # Test booking status with no bookings made
        self.assertEqual(self.trip.booking_status(),
                         'No bookings yet. Budget: 10000.00')

    def test_booking_status_with_bookings(self):
        # Test booking status with bookings made
        self.trip.book_a_trip('Australia')
        self.trip.book_a_trip('Brazil')
        expected_output = """Booked Destination: Australia
Paid Amount: 22800.00
Booked Destination: Brazil
Paid Amount: 24800.00
Number of Travelers: 4
Budget Left: 52400.00"""
        self.assertEqual(self.trip.booking_status(), expected_output)

    def test_setter_travelers(self):
        # Test setting number of travelers
        with self.assertRaises(ValueError):
            self.trip.travelers = 0

    def test_setter_is_family(self):
        # Test setting is_family with less than 2 travelers
        self.trip.travelers = 1
        self.assertFalse(self.trip.is_family)


if __name__ == '__main__':
    unittest.main()
