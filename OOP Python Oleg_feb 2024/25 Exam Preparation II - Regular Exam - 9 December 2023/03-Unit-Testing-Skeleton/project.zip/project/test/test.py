import unittest

from project.railway_station import RailwayStation


class TestRailwayStation(unittest.TestCase):

    def setUp(self):
        self.station = RailwayStation("Test Station")

    def test_station_name(self):
        with self.assertRaises(ValueError):
            station = RailwayStation("Sta")

    def test_new_arrival_on_board(self):
        self.station.new_arrival_on_board("Train A")
        self.assertEqual(self.station.arrival_trains[0], "Train A")

    def test_train_has_arrived(self):
        self.station.new_arrival_on_board("Train A")
        result = self.station.train_has_arrived("Train A")
        self.assertEqual(result, "Train A is on the platform and will leave in 5 minutes.")

    # def test_train_has_arrived_before_other_trains(self):
    #     self.station.new_arrival_on_board("Train A")
    #     self.station.new_arrival_on_board("Train B")
    #     result = self.station.train_has_arrived("Train A")
    #     self.assertEqual(result, "There are other trains to arrive before Train A.")

    def test_train_has_left(self):
        self.station.new_arrival_on_board("Train A")
        self.station.train_has_arrived("Train A")
        result = self.station.train_has_left("Train A")
        self.assertTrue(result)

    def test_train_has_left_nonexistent_train(self):
        result = self.station.train_has_left("Train X")
        self.assertFalse(result)


if __name__ == '__main__':
    unittest.main()
