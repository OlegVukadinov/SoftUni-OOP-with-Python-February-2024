from project.fruit import Fruit

fruit = Fruit("banana", "2024-03-01")
print(fruit.name)